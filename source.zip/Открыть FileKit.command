#!/bin/zsh
cd "$(dirname "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null; then
  echo 'Для запуска нужен Node.js LTS: https://nodejs.org/'
  read '?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
if [ ! -d node_modules ]; then
  npm ci || exit 1
fi
if [ ! -f dist/index.html ]; then
  npm run build || exit 1
fi
npm run preview -- --port 4177 --strictPort &
server_pid=$!
trap 'kill $server_pid 2>/dev/null' EXIT INT TERM
sleep 2
open 'http://127.0.0.1:4177/'
wait $server_pid
