import {useEffect,useRef,useState} from 'react';
import {ChevronLeft,ChevronRight,FileText,LoaderCircle} from 'lucide-react';
import {pdfJob} from '../engines/client';
import type {Values} from '../types';
type Info={width:number;height:number;pages:number};
export function Preview({file,tool,values,onChange}:{file:File;tool:string;values:Values;onChange:(key:string,value:number|string)=>void}){
 const [url,setUrl]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[page,setPage]=useState(0),[info,setInfo]=useState<Info>({width:1,height:1,pages:1});
 const start=useRef<{x:number;y:number}|null>(null);
 const isPDF=/\.pdf$/i.test(file.name);
 useEffect(()=>{setPage(0);},[file]);
 useEffect(()=>{
  const abort=new AbortController();let objectURL='';setUrl('');setError('');setBusy(true);
  (async()=>{try{
   if(isPDF){const results=await pdfJob({tool:'preview',files:[{name:file.name,type:file.type,data:await file.arrayBuffer()}],options:{page}},()=>{},abort.signal);setInfo(JSON.parse(new TextDecoder().decode(results[1].data)));objectURL=URL.createObjectURL(new Blob([new Uint8Array(results[0].data)],{type:'image/png'}));}
   else if(/\.(docx|xlsx|html?)$/i.test(file.name)){setError('Документ готов к обработке. Предпросмотр будет доступен для результата PDF.');return;}
   else {const {loadImage}=await import('../engines/image');const image=await loadImage({name:file.name,type:file.type,data:await file.arrayBuffer()});if(abort.signal.aborted)return;setInfo({width:image.naturalWidth,height:image.naturalHeight,pages:1});const c=document.createElement('canvas'),ratio=Math.min(1,1200/image.naturalWidth);c.width=image.naturalWidth*ratio;c.height=image.naturalHeight*ratio;c.getContext('2d')!.drawImage(image,0,0,c.width,c.height);objectURL=await new Promise<string>(resolve=>c.toBlob(blob=>resolve(blob?URL.createObjectURL(blob):''),'image/png'));}
   if(!abort.signal.aborted)setUrl(objectURL);else if(objectURL)URL.revokeObjectURL(objectURL);
  }catch(e){if(!abort.signal.aborted)setError(e instanceof Error?e.message:'Предпросмотр недоступен');}finally{if(!abort.signal.aborted)setBusy(false);}})();
  return()=>{abort.abort();if(objectURL)URL.revokeObjectURL(objectURL);};
 },[file,page,isPDF]);
 const area=tool==='redact'||tool==='blur'||(tool==='crop-image'&&values.ratio==='Свободно');
 const bounds=(e:React.PointerEvent)=>{const r=e.currentTarget.getBoundingClientRect();return {x:Math.max(0,Math.min(info.width,(e.clientX-r.left)/r.width*info.width)),y:Math.max(0,Math.min(info.height,(e.clientY-r.top)/r.height*info.height))};};
 return <div className="preview"><div className="preview-top"><span>Предпросмотр</span><span>{isPDF?`${info.pages} стр.`:`${info.width>1?`${info.width} × ${info.height} px`:''}`}</span></div>
 <div className="preview-stage">{busy?<div className="preview-placeholder"><LoaderCircle className="spin"/><p>Готовим предпросмотр…</p></div>:error?<div className="preview-placeholder"><FileText size={38}/><p>{error}</p></div>:url&&<div className={`preview-image ${area?'select-area':''}`} onPointerDown={e=>{if(!area)return;start.current=bounds(e);e.currentTarget.setPointerCapture(e.pointerId);}} onPointerMove={e=>{if(!start.current)return;const p=bounds(e),s=start.current;onChange('x',Math.floor(Math.min(p.x,s.x)));onChange('y',Math.floor(Math.min(p.y,s.y)));onChange('width',Math.max(1,Math.floor(Math.abs(p.x-s.x))));onChange('height',Math.max(1,Math.floor(Math.abs(p.y-s.y))));}} onPointerUp={()=>{start.current=null;}} onPointerCancel={()=>{start.current=null;}}><img src={url} alt={`Предпросмотр ${file.name}`} draggable={false}/>{area&&<div className="selection-box" style={{left:`${Number(values.x??0)/info.width*100}%`,top:`${Number(values.y??0)/info.height*100}%`,width:`${Math.min(100,Number(values.width??0)/info.width*100)}%`,height:`${Math.min(100,Number(values.height??0)/info.height*100)}%`}}/>}</div>}</div>
 {area&&<p className="preview-hint">Потяните по изображению, чтобы выделить область.{isPDF?' Область применяется к страницам, указанным в настройках.':''}</p>}
 {isPDF&&info.pages>1&&<div className="pagination"><button disabled={page===0||busy} aria-label="Предыдущая страница" onClick={()=>setPage(p=>p-1)}><ChevronLeft size={17}/></button><span>{page+1} / {info.pages}</span><button disabled={page>=info.pages-1||busy} aria-label="Следующая страница" onClick={()=>setPage(p=>p+1)}><ChevronRight size={17}/></button></div>}
 </div>;
}
