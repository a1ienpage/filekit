import {useEffect,useRef,useState} from 'react';
import {ArrowLeft,ArrowRight,Upload,Plus,X,ArrowUp,ArrowDown,ShieldCheck,Download,LoaderCircle,Check,RotateCcw,Info,FileText,ChevronDown} from 'lucide-react';
import type {Tool,ResultFile,Values} from '../types';
import {defaults,tools} from '../catalog';
import {Icon} from './Icon';
import {Options,Signature} from './Options';
import {Preview} from './Preview';
import {FormFields} from './FormFields';
import {sizeLabel,checkAbort} from '../engines/utils';
import {pdfJob} from '../engines/client';
const advanced=['images-pdf','ocr-pdf','ocr-image','background','upscale','docx-pdf','xlsx-pdf','html-pdf'];
const accepts=(tool:Tool,f:File)=>tool.accept.split(',').some(ext=>f.name.toLowerCase().endsWith(ext));
function saveBlob(blob:Blob,name:string){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}
export function Workspace({tool,initialFiles=[],onBack,onNext}:{tool:Tool;initialFiles?:File[];onBack:()=>void;onNext:(tool:Tool,files:File[])=>void}){
 const [files,setFiles]=useState<File[]>(initialFiles),[values,setValues]=useState<Values>(defaults(tool)),[active,setActive]=useState(0),[results,setResults]=useState<ResultFile[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),[progress,setProgress]=useState(0),[message,setMessage]=useState(''),[drag,setDrag]=useState(false),[showResult,setShowResult]=useState(false);
 const input=useRef<HTMLInputElement>(null),controller=useRef<AbortController|null>(null),form=useRef<HTMLFormElement>(null);
 useEffect(()=>()=>controller.current?.abort(),[]);
 const change=(key:string,value:string|number|boolean)=>{if(!busy)setValues(v=>({...v,[key]:value}));};
 const add=(incoming:File[])=>{
  setError('');const valid=incoming.filter(f=>accepts(tool,f));if(valid.length!==incoming.length)setError(`Поддерживаемые форматы: ${tool.accept.replaceAll(',',' ')}.`);
  const merged=(tool.multiple===false?valid.slice(0,1):[...files,...valid]).filter((f,i,arr)=>arr.findIndex(x=>x.name===f.name&&x.size===f.size&&x.lastModified===f.lastModified)===i);
  if(merged.length>100||merged.reduce((n,f)=>n+f.size,0)>250*1024*1024){setError('За один раз можно выбрать до 100 файлов общим размером до 250 МБ.');return;}
  if(merged.some(f=>f.size===0)){setError('Один из файлов пуст. Выберите другой файл.');return;}
  setFiles(merged);setResults([]);setShowResult(false);
 };
 const run=async()=>{
  if(!form.current?.reportValidity())return;
  if(files.length<(tool.minFiles??1)){setError(`Добавьте минимум ${tool.minFiles??1} файл(а).`);return;}
  setBusy(true);setError('');setResults([]);setProgress(0);setMessage('Подготавливаем файлы…');setShowResult(false);controller.current=new AbortController();const signal=controller.current.signal;
  try{
   const inputFiles=await Promise.all(files.map(async f=>({name:f.name,type:f.type,data:await f.arrayBuffer()})));checkAbort(signal);
   const job={tool:tool.id,files:inputFiles,options:values},update=(value:number,msg:string)=>{if(!signal.aborted){setProgress(Math.min(100,Math.max(0,value)));setMessage(msg);}};
   const output=advanced.includes(tool.id)?await (await import('../engines/advanced')).runAdvanced(job,update,signal):tool.group==='pdf'?await pdfJob(job,update,signal):await (await import('../engines/image')).runImage(job,update,signal);
   checkAbort(signal);if(!output.length)throw new Error('Не удалось создать результат.');
   const used=new Set<string>();for(const file of output){let name=file.name,n=2;while(used.has(name)){name=file.name.replace(/(\.[^.]+)$/,`-${n++}$1`);}file.name=name;used.add(name);}
   setResults(output);setProgress(100);setMessage('Готово');setShowResult(true);
  }catch(e){if(signal.aborted)setError('Обработка отменена. Исходные файлы сохранены.');else setError(e instanceof Error?e.message:'Не удалось обработать файл.');}
  finally{setBusy(false);controller.current=null;}
 };
 const download=(r:ResultFile)=>saveBlob(new Blob([new Uint8Array(r.data)],{type:r.type}),r.name);
 const downloadAll=async()=>{if(results.length===1){download(results[0]);return;}try{const {default:JSZip}=await import('jszip');const zip=new JSZip();results.forEach(r=>zip.file(r.name,r.data));saveBlob(await zip.generateAsync({type:'blob'}),'filekit-results.zip');}catch{setError('Не удалось собрать ZIP. Скачайте файлы по одному.');}};
 const resultFiles=results.map(r=>new File([new Uint8Array(r.data)],r.name,{type:r.type}));
 const nextTools=tools.filter(t=>resultFiles.length&&resultFiles.every(f=>accepts(t,f)));
 const total=files.reduce((n,f)=>n+f.size,0),outputSize=results.reduce((n,r)=>n+r.data.byteLength,0);
 const resultPreview=useRef<{result:ResultFile;file:File}|null>(null);
 if(results[0]&&resultPreview.current?.result!==results[0])resultPreview.current={result:results[0],file:resultFiles[0]};
 return <main className="workspace shell"><button className="back" onClick={onBack} disabled={busy}><ArrowLeft size={17}/> Все инструменты</button><div className="workspace-heading"><span className={`tool-icon ${tool.group}`}><Icon name={tool.icon} size={28}/></span><div><div className="eyebrow">{tool.group==='pdf'?'PDF ИНСТРУМЕНТЫ':'ИЗОБРАЖЕНИЯ'}{tool.badge&&<span className="badge">{tool.badge}</span>}</div><h1>{tool.name}</h1><p>{tool.desc}</p></div></div>
 <input type="file" ref={input} accept={tool.accept} multiple={tool.multiple} hidden onChange={e=>{if(e.target.files)add([...e.target.files]);e.target.value='';}}/>
 <div className="workspace-grid"><section className="work-main" onDragOver={e=>{e.preventDefault();if(!busy)setDrag(true);}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);if(!busy)add([...e.dataTransfer.files]);}}>
 {!files.length?<button className={`dropzone ${drag?'dragging':''}`} onClick={()=>input.current?.click()}><div className="upload-illustration"><div className="upload-paper"><FileText size={44} strokeWidth={1.3}/></div><span><Plus size={24}/></span></div><h2>Начнём с ваших файлов</h2><p>Перетащите их сюда или выберите на устройстве</p><span className="primary"><Upload size={18}/> Выбрать файлы</span><small>{tool.accept.toUpperCase().replaceAll('.', '').replaceAll(',', ' · ')}<br/>До 100 файлов · до 250 МБ суммарно</small></button>:<>
 <div className="file-toolbar"><span><b>{files.length}</b> файл(а) <span className="muted">· {sizeLabel(total)}</span></span><button className="secondary small" disabled={busy} onClick={()=>input.current?.click()}><Plus size={16}/> Добавить</button></div>
 <div className="file-list">{files.map((file,i)=><div className={`file-row ${active===i&&!showResult?'selected':''}`} key={`${file.name}-${file.lastModified}-${i}`}><button className="file-name" disabled={busy} onClick={()=>{setActive(i);setShowResult(false);}}><FileText size={20}/><span>{file.name}<small>{sizeLabel(file.size)}</small></span></button><div className="file-actions"><button aria-label={`Поднять ${file.name}`} disabled={i===0||busy} onClick={()=>setFiles(f=>{const a=[...f];[a[i-1],a[i]]=[a[i],a[i-1]];return a;})}><ArrowUp size={15}/></button><button aria-label={`Опустить ${file.name}`} disabled={i===files.length-1||busy} onClick={()=>setFiles(f=>{const a=[...f];[a[i+1],a[i]]=[a[i],a[i+1]];return a;})}><ArrowDown size={15}/></button><button aria-label={`Удалить ${file.name}`} disabled={busy} onClick={()=>{setFiles(f=>f.filter((_,j)=>i!==j));setActive(0);setResults([]);setShowResult(false);}}><X size={16}/></button></div></div>)}</div>
 {results.length>0&&<div className="result-panel"><div className="result-title"><span className="success-icon"><Check size={23}/></span><div><h2>Готово. Можно скачивать.</h2><p>{results.length} файл(а) · {sizeLabel(outputSize)}{['compress','compress-image'].includes(tool.id)&&outputSize<total?` · меньше на ${Math.min(99.9,(1-outputSize/total)*100).toFixed(1)}%`:''}</p></div></div><button className="primary" onClick={downloadAll}><Download size={18}/>{results.length>1?'Скачать всё ZIP':'Скачать файл'}</button>{results.length>1&&<details><summary>Все результаты <ChevronDown size={15}/></summary><div className="result-list">{results.map(r=><button key={r.name} onClick={()=>download(r)}><span>{r.name}</span><Download size={15}/></button>)}</div></details>}{nextTools.length>0&&<div className="next-tool"><label htmlFor="next-tool">Продолжить с результатом</label><select id="next-tool" value="" onChange={e=>{const next=tools.find(t=>t.id===e.target.value);if(next)onNext(next,resultFiles);}}><option value="">Выберите следующий инструмент…</option>{nextTools.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></div>}</div>}
 {showResult&&resultPreview.current&&/\.(pdf|png|jpe?g|webp|gif)$/i.test(resultPreview.current.file.name)?<><div className="result-preview-label">Результат <button className="text-button" onClick={()=>setShowResult(false)}>Показать оригинал</button></div><Preview file={resultPreview.current.file} tool="result" values={{}} onChange={()=>{}}/></>:files[active]&&<Preview file={files[active]} tool={busy?'busy':tool.id} values={values} onChange={change}/>}
 </>}
 </section><aside className="settings-panel"><form ref={form} onSubmit={e=>{e.preventDefault();void run();}}><div className="settings-title"><h2>Настройки</h2><button type="button" aria-label="Сбросить настройки" title="Сбросить настройки" disabled={busy} onClick={()=>setValues(defaults(tool))}><RotateCcw size={17}/></button></div>{tool.id==='fill-form'?<FormFields file={files[0]} disabled={busy} onChange={v=>change('formValues',v)}/>:tool.fields.length?<Options fields={tool.fields} values={values} onChange={change} disabled={busy}/>:<p className="auto-settings">Всё уже настроено.<br/>Добавьте файлы и начните обработку.</p>}{tool.id==='sign'&&<Signature disabled={busy} onChange={v=>change('signature',v)}/>} {tool.note&&<div className="tool-note"><Info size={16}/><p>{tool.note}</p></div>}
 {tool.group==='image'&&!['gif','ocr-image'].includes(tool.id)&&<p className="tiny-note">Анимированный GIF обрабатывается первым кадром.</p>}
 {error&&<div className="error" role="alert">{error}</div>}
 {busy?<div className="processing" role="status" aria-live="polite"><div><LoaderCircle size={17} className="spin"/><span>{message}</span></div><progress max={100} value={progress}/><button type="button" className="secondary" onClick={()=>{controller.current?.abort();setMessage('Отменяем обработку…');}}>Отменить</button></div>:<button type="submit" className="primary run" disabled={!files.length}>Обработать {files.length>1?`(${files.length})`:''}<ArrowRight size={19}/></button>}
 <div className="local-note"><ShieldCheck size={17}/><span>Файлы обрабатываются<br/>на вашем устройстве</span></div></form></aside></div>
 </main>;
}
