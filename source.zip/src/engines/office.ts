import type {Job,Progress,ResultFile} from '../types';
import {checkAbort,outputName} from './utils';
import DOMPurify from 'dompurify';
export function sanitizeDocument(html:string){
 const clean=DOMPurify.sanitize(html,{USE_PROFILES:{html:true},FORBID_TAGS:['style','link','iframe','form','input','button','video','audio','source','object','embed'],FORBID_ATTR:['style','srcset','background']});
 const template=document.createElement('template');template.innerHTML=clean;
 template.content.querySelectorAll('[src]').forEach(el=>{if(!/^data:image\/(png|jpeg|gif|webp);base64,/i.test(el.getAttribute('src')??''))el.removeAttribute('src');});
 template.content.querySelectorAll('a').forEach(el=>el.removeAttribute('href'));
 return template.innerHTML;
}
export async function runOffice({tool,files}:Job,progress:Progress,signal?:AbortSignal):Promise<ResultFile[]>{
 const [{default:html2canvas},{jsPDF}]=await Promise.all([import('html2canvas'),import('jspdf')]),out:ResultFile[]=[];
 for(let i=0;i<files.length;i++){
  checkAbort(signal);const file=files[i];let html='';
  if(tool==='docx-pdf'){const mammoth=await import('mammoth');html=(await mammoth.convertToHtml({arrayBuffer:file.data})).value;}
  else if(tool==='xlsx-pdf'){
   const {default:ExcelJS}=await import('exceljs');const wb=new ExcelJS.Workbook();await wb.xlsx.load(file.data);const wrap=document.createElement('div');let cells=0;
   wb.eachSheet(sheet=>{const title=document.createElement('h2');title.textContent=sheet.name;wrap.append(title);const table=document.createElement('table');sheet.eachRow(row=>{const tr=document.createElement('tr');row.eachCell({includeEmpty:true},cell=>{if(++cells>5000)throw new Error('Для экспорта поддерживается до 5000 ячеек.');const td=document.createElement('td');td.textContent=cell.text;tr.append(td);});table.append(tr);});wrap.append(table);});html=wrap.innerHTML;
  }else html=new TextDecoder().decode(file.data);
  const host=document.createElement('div');host.className='document-render';host.innerHTML=sanitizeDocument(html);document.body.append(host);
  try{
   if(host.scrollHeight>24000)throw new Error('Документ слишком длинный для браузерного экспорта. Разделите его на части.');
   const images=[...host.querySelectorAll('img')];await Promise.all(images.map(im=>im.decode().catch(()=>{})));checkAbort(signal);
   const c=await html2canvas(host,{scale:1.5,backgroundColor:'#ffffff',logging:false,allowTaint:false,useCORS:false});checkAbort(signal);
   const pdf=new jsPDF({unit:'pt',format:'a4'}),pageW=595.28,pageH=841.89,margin=32,drawW=pageW-margin*2,sliceH=Math.floor((pageH-margin*2)*c.width/drawW);
   for(let y=0;y<c.height;y+=sliceH){checkAbort(signal);if(y>0)pdf.addPage();const slice=document.createElement('canvas');slice.width=c.width;slice.height=Math.min(sliceH,c.height-y);slice.getContext('2d')!.drawImage(c,0,y,c.width,slice.height,0,0,c.width,slice.height);pdf.addImage(slice.toDataURL('image/jpeg',0.92),'JPEG',margin,margin,drawW,slice.height*drawW/c.width);slice.width=1;slice.height=1;}
   out.push({name:outputName(file.name,'converted','pdf'),type:'application/pdf',data:new Uint8Array(pdf.output('arraybuffer'))});c.width=1;c.height=1;
  }finally{host.remove();}
  progress((i+1)/files.length*100,`Документ ${i+1} из ${files.length}`);
 }
 return out;
}
