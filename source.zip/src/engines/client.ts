import type {Job,Progress,ResultFile} from '../types';
export function pdfJob(job:Job,progress:Progress,signal?:AbortSignal):Promise<ResultFile[]>{
 return new Promise((resolve,reject)=>{
  if(signal?.aborted){reject(new DOMException('Отменено','AbortError'));return;}
  const worker=new Worker(new URL('./worker.ts',import.meta.url),{type:'module'});
  const cleanup=()=>{worker.terminate();signal?.removeEventListener('abort',abort);};
  const abort=()=>{cleanup();reject(new DOMException('Отменено','AbortError'));};signal?.addEventListener('abort',abort,{once:true});
  worker.onmessage=e=>{if(e.data.error){cleanup();reject(new Error(e.data.error));}else if(e.data.files){cleanup();resolve(e.data.files);}else progress(e.data.progress,e.data.message);};
  worker.onerror=e=>{cleanup();reject(new Error(e.message||'Не удалось загрузить обработчик PDF. Перезагрузите страницу.'));};
  worker.postMessage(job);
 });
}
