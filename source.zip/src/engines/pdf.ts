import {PDFDocument, PDFName, PDFTextField, PDFCheckBox, PDFDropdown, PDFOptionList, PDFRadioGroup, StandardFonts, degrees, rgb} from 'pdf-lib';
import type {Job,Progress,ResultFile} from '../types';
import {parsePages,outputName} from './utils';
const result=(name:string,data:Uint8Array):ResultFile=>({name,type:'application/pdf',data});
async function fontFor(doc:PDFDocument,text:string){
 if(/[^\x20-\x7E\n\r]/.test(text)){
  const [{default:fontkit},font]=await Promise.all([import('@pdf-lib/fontkit'),fetch(new URL('../assets/NotoSans-Regular.ttf',import.meta.url)).then(r=>r.arrayBuffer())]);
  doc.registerFontkit(fontkit);return doc.embedFont(font,{subset:true});
 }
 return doc.embedFont(StandardFonts.Helvetica);
}
export async function runPDF({tool,files,options:o}:Job,progress:Progress):Promise<ResultFile[]>{
 if(!files.length)throw new Error('Выберите хотя бы один файл.');
 const nativeTools=['compress','protect','unlock','repair','redact','pdf-images','pdf-text','pdf-word','pdf-pptx','pdf-excel','compare','preview','extract-images'];
 if(nativeTools.includes(tool))return (await import('./native-pdf')).runNative({tool,files,options:o},progress);
 const out:ResultFile[]=[];
 if(tool==='merge'){
  const target=await PDFDocument.create();
  for(let i=0;i<files.length;i++){
   const source=await PDFDocument.load(files[i].data);
   for(const p of await target.copyPages(source,source.getPageIndices()))target.addPage(p);
   progress((i+1)/files.length*95,`Объединяем ${i+1} из ${files.length}`);
  }
  return [result('filekit-merged.pdf',await target.save())];
 }
 for(let f=0;f<files.length;f++){
  const file=files[f],doc=await PDFDocument.load(file.data,{updateMetadata:false});
  const indices=parsePages(String(o.pages??''),doc.getPageCount());
  if(tool==='split'){
   const chunk=Math.max(1,Number(o.chunk??1));
   for(let i=0;i<doc.getPageCount();i+=chunk){const d=await PDFDocument.create();for(const p of await d.copyPages(doc,doc.getPageIndices().slice(i,i+chunk)))d.addPage(p);out.push(result(outputName(file.name,`pages-${i+1}-${Math.min(i+chunk,doc.getPageCount())}`,'pdf'),await d.save()));}
  }else if(tool==='organize'||tool==='extract'){
   const d=await PDFDocument.create();for(const p of await d.copyPages(doc,indices))d.addPage(p);out.push(result(outputName(file.name,tool,'pdf'),await d.save()));
  }else{
   if(tool==='remove'){
    if(!String(o.pages??'').trim())throw new Error('Укажите страницы для удаления.');
    const unique=[...new Set(indices)].sort((a,b)=>b-a);if(unique.length===doc.getPageCount())throw new Error('Нельзя удалить все страницы.');unique.forEach(i=>doc.removePage(i));
   }else if(tool==='rotate-pdf'){for(const i of indices){const p=doc.getPage(i);p.setRotation(degrees((p.getRotation().angle+Number(o.angle??90))%360));}}
   else if(tool==='crop-pdf'){for(const i of indices){const p=doc.getPage(i),b=p.getCropBox(),m=Number(o.margin??24);if(m*2>=Math.min(b.width,b.height))throw new Error('Отступ слишком большой для этой страницы.');p.setCropBox(b.x+m,b.y+m,b.width-2*m,b.height-2*m);}}
   else if(tool==='create-form'){
    const names=String(o.names??'').split('\n').map(x=>x.trim()).filter(Boolean);if(!names.length||names.length>100)throw new Error('Введите от 1 до 100 названий полей.');
    const form=doc.getForm(),font=await fontFor(doc,names.join(' '));let page=doc.addPage([595.28,841.89]),y=780;
    for(const name of names){if(form.getFieldMaybe(name))throw new Error(`Поле «${name}» уже существует.`);if(y<90){page=doc.addPage([595.28,841.89]);y=780;}page.drawText(name,{x:40,y,font,size:12});const field=form.createTextField(name);field.addToPage(page,{x:40,y:y-40,width:515,height:30,font,borderWidth:1});y-=85;}
    form.updateFieldAppearances(font);
   }else if(tool==='fill-form'){
    const form=doc.getForm();if(form.hasXFA())throw new Error('Формы XFA не поддерживаются.');const values=JSON.parse(String(o.formValues??'{}'));if(!Object.keys(values).length)throw new Error('Заполните хотя бы одно поле.');const font=await fontFor(doc,Object.values(values).join(' '));
    for(const [name,value] of Object.entries(values)){const field=form.getField(name);if(field.isReadOnly())continue;if(field instanceof PDFTextField)field.setText(String(value));else if(field instanceof PDFCheckBox){if(value)field.check();else field.uncheck();}else if(field instanceof PDFDropdown||field instanceof PDFOptionList||field instanceof PDFRadioGroup){if(value)field.select(String(value));}}
    form.updateFieldAppearances(font);
   }
   else if(tool==='flatten'){const form=doc.getForm();if(form.hasXFA())throw new Error('Формы XFA не поддерживаются.');form.flatten();}
   else if(tool==='metadata'){doc.setTitle(String(o.title??''));doc.setAuthor(String(o.author??''));doc.setSubject(String(o.subject??''));}
   else if(tool==='clean-pdf'){
    doc.setTitle('');doc.setAuthor('');doc.setSubject('');doc.setKeywords([]);doc.setProducer('');doc.setCreator('');
    const info=doc.context.lookup(doc.context.trailerInfo.Info);if(info&&'delete' in info){(info as {delete:(key:PDFName)=>void}).delete(PDFName.of('CreationDate'));(info as {delete:(key:PDFName)=>void}).delete(PDFName.of('ModDate'));}
    doc.catalog.delete(PDFName.of('Metadata'));
   }else if(tool==='sign'){
    if(!o.signature)throw new Error('Нарисуйте подпись перед обработкой.');
    const im=await doc.embedPng(String(o.signature));
    for(const i of indices){const p=doc.getPage(i),b=p.getCropBox(),w=Math.min(Number(o.signatureWidth??150),b.width-40),h=w*im.height/im.width;p.drawImage(im,{x:b.x+(b.width-w)/2,y:b.y+(o.position==='Сверху'?b.height-h-30:o.position==='По центру'?(b.height-h)/2:30),width:w,height:h});}
   }else if(['numbers','watermark-pdf','text-pdf'].includes(tool)){
    const label=String(o.text??'');if(tool!=='numbers'&&!label.trim())throw new Error('Введите текст.');
    const font=await fontFor(doc,label),hex=String(o.color??'#4158ed').replace('#',''),c=rgb(parseInt(hex.slice(0,2),16)/255,parseInt(hex.slice(2,4),16)/255,parseInt(hex.slice(4,6),16)/255);
    for(const i of indices){const p=doc.getPage(i),b=p.getCropBox(),t=tool==='numbers'?String(i+Number(o.start??1)):label;
     const size=Math.min(Number(o.size??20),(b.width-40)/Math.max(font.widthOfTextAtSize(t,1),1));
     const x=b.x+(b.width-font.widthOfTextAtSize(t,size))/2,y=b.y+(o.position==='Сверху'?b.height-size-30:o.position==='По центру'?(b.height-size)/2:30);
     p.drawText(t,{x,y,font,size,color:c,opacity:tool==='watermark-pdf'?Number(o.opacity??25)/100:1});
    }
   }else throw new Error('Неизвестный инструмент PDF.');
   const saved=await doc.save();
   if(tool==='clean-pdf'){
    const {runNative}=await import('./native-pdf');const [clean]=await runNative({tool:'repair',files:[{name:file.name,type:'application/pdf',data:new Uint8Array(saved).buffer}],options:{}},()=>{});out.push(result(outputName(file.name,tool,'pdf'),clean.data));
   }else out.push(result(outputName(file.name,tool,'pdf'),saved));
  }
  progress((f+1)/files.length*100,`Готово ${f+1} из ${files.length}`);
 }
 return out;
}
