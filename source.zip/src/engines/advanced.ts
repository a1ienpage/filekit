import type {Job,Progress,ResultFile} from '../types';
import {bytes,checkAbort,outputName} from './utils';
import {loadImage,canvas,canvasResult} from './image';
import {pdfJob} from './client';
import {PDFDocument} from 'pdf-lib';
async function unicodeFont(doc:PDFDocument){const {default:fontkit}=await import('@pdf-lib/fontkit');doc.registerFontkit(fontkit);return doc.embedFont(await fetch(new URL('../assets/NotoSans-Regular.ttf',import.meta.url)).then(r=>r.arrayBuffer()),{subset:true});}
export async function runAdvanced(job:Job,progress:Progress,signal?:AbortSignal):Promise<ResultFile[]>{
 const {tool,files,options:o}=job,out:ResultFile[]=[];
 if(tool==='images-pdf'){
  const doc=await PDFDocument.create();
  for(let i=0;i<files.length;i++){checkAbort(signal);const im=await loadImage(files[i]),{c,ctx}=canvas(im.width,im.height);ctx.drawImage(im,0,0);const png=await canvasResult(c,'image.png');const embed=await doc.embedPng(png.data),margin=Number(o.margin??24);const w=o.paper==='По изображению'?im.width+margin*2:595.28,h=o.paper==='По изображению'?im.height+margin*2:841.89;const ratio=Math.min((w-margin*2)/im.width,(h-margin*2)/im.height);doc.addPage([w,h]).drawImage(embed,{x:(w-im.width*ratio)/2,y:(h-im.height*ratio)/2,width:im.width*ratio,height:im.height*ratio});c.width=1;c.height=1;progress((i+1)/files.length*95,`Изображение ${i+1}`);}
  return [{name:'filekit-images.pdf',type:'application/pdf',data:await doc.save()}];
 }
 if(tool==='ocr-image'||tool==='ocr-pdf'){
  const {createWorker}=await import('tesseract.js');let current=0,total=files.length;
  const worker=await createWorker(String(o.language??'rus+eng'),1,{workerPath:new URL(`${import.meta.env.BASE_URL}ocr/worker.min.js`,document.baseURI).href,corePath:new URL(`${import.meta.env.BASE_URL}ocr/tesseract-core-lstm.wasm.js`,document.baseURI).href,langPath:new URL(`${import.meta.env.BASE_URL}ocr/`,document.baseURI).href,workerBlobURL:false,logger:m=>progress(Math.min(95,(current+(m.progress??0))/total*95),m.status==='recognizing text'?'Распознаём текст…':'Загружаем OCR…')});
  const stop=()=>{void worker.terminate();};signal?.addEventListener('abort',stop,{once:true});
  try{
   for(const file of files){
    checkAbort(signal);
    const images=tool==='ocr-pdf'?await pdfJob({tool:'pdf-images',files:[file],options:{format:'png',scale:o.scale??1.5}},progress,signal):[{name:file.name,type:file.type,data:new Uint8Array(file.data)}];
    if(images.length>150)throw new Error('OCR: максимум 150 страниц за одну операцию.');
    const doc=o.format==='PDF с поиском'?await PDFDocument.create():null,font=doc?await unicodeFont(doc):null;
    const text:string[]=[];
    for(let i=0;i<images.length;i++){
     checkAbort(signal);const im=await loadImage(new Blob([new Uint8Array(images[i].data)],{type:images[i].type}));
     const ocrCanvas=canvas(im.width,im.height);ocrCanvas.ctx.drawImage(im,0,0);const {data}=await worker.recognize(ocrCanvas.c,{}, {text:true,blocks:true});ocrCanvas.c.width=1;ocrCanvas.c.height=1;checkAbort(signal);text.push(data.text);
     if(doc&&font){
      const {c,ctx}=canvas(im.width,im.height);ctx.drawImage(im,0,0);const png=await canvasResult(c,'ocr.png');const scale=Number(o.scale??1.5),w=im.width/scale,h=im.height/scale;const page=doc.addPage([w,h]),embed=await doc.embedPng(png.data);page.drawImage(embed,{x:0,y:0,width:w,height:h});
      for(const block of data.blocks??[])for(const par of block.paragraphs)for(const line of par.lines)for(const word of line.words){const t=word.text.trim();if(!t)continue;const b=word.bbox,boxW=(b.x1-b.x0)/scale;const size=Math.min((b.y1-b.y0)/scale,boxW/Math.max(font.widthOfTextAtSize(t,1),0.01));if(size>0)page.drawText(t,{x:b.x0/scale,y:h-b.y1/scale,font,size,opacity:0});}
      c.width=1;c.height=1;
     }
     progress((i+1)/images.length*95,`Распознана страница ${i+1} из ${images.length}`);
    }
    out.push(doc?{name:outputName(file.name,'searchable','pdf'),type:'application/pdf',data:await doc.save()}:{name:outputName(file.name,'ocr','txt'),type:'text/plain',data:bytes(text.join('\n\n'))});current++;
   }
  }finally{signal?.removeEventListener('abort',stop);await worker.terminate();}
  return out;
 }
 if(tool==='background'){
  const {removeBackground}=await import('@imgly/background-removal');
  for(let i=0;i<files.length;i++){checkAbort(signal);const im=await loadImage(files[i]),{c,ctx}=canvas(im.width,im.height);ctx.drawImage(im,0,0);const png=await canvasResult(c,'source.png');progress(10,'Загружаем модель и выделяем объект…');const blob=await removeBackground(new Blob([new Uint8Array(png.data)],{type:'image/png'}),{model:'isnet_quint8',device:'cpu',fetchArgs:{signal},progress:(key,current,total)=>progress(total?current/total*75:10,`Модель: ${key.includes('fetch')?'загрузка':'обработка'}…`)});checkAbort(signal);out.push({name:outputName(files[i].name,'no-background','png'),type:'image/png',data:new Uint8Array(await blob.arrayBuffer())});c.width=1;c.height=1;progress((i+1)/files.length*100,'Фон удалён');}
  return out;
 }
 if(tool==='upscale'){
  const {upscaleImage}=await import('./upscale');
  for(const file of files){checkAbort(signal);const im=await loadImage(file);if(im.width>1500||im.height>1500)throw new Error('AI-увеличение: сначала уменьшите изображение до 1500 × 1500 px.');progress(5,'Загружаем модель увеличения…');const c=await upscaleImage(im,progress,signal);out.push(await canvasResult(c,outputName(file.name,'2x','png')));c.width=1;c.height=1;}
  return out;
 }
 if(['docx-pdf','html-pdf','xlsx-pdf'].includes(tool))return (await import('./office')).runOffice(job,progress,signal);
 throw new Error('Неизвестный инструмент.');
}
