import type {Job,Progress,ResultFile,InputFile} from '../types';
import {checkAbort,checkPixels,fitSize,outputName,safeDimension,tick} from './utils';
export async function loadImage(file:InputFile|Blob):Promise<HTMLImageElement>{
 let blob=file instanceof Blob?file:new Blob([file.data],{type:file.type});
 if(!(file instanceof Blob)&&/\.hei[cf]$/i.test(file.name)){
  const {heicTo}=await import('heic-to');blob=await heicTo({blob,type:'image/png'});
 }
 if(blob.type==='image/svg+xml'||(!(file instanceof Blob)&&/\.svg$/i.test(file.name))){
  const {default:DOMPurify}=await import('dompurify');const clean=DOMPurify.sanitize(await blob.text(),{USE_PROFILES:{svg:true,svgFilters:true},FORBID_TAGS:['foreignObject','script','image','use','style','a'],FORBID_ATTR:['href','xlink:href']});blob=new Blob([clean],{type:'image/svg+xml'});
 }
 const url=URL.createObjectURL(blob);
 try{return await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{try{checkPixels(img.naturalWidth,img.naturalHeight);resolve(img);}catch(e){reject(e);}};img.onerror=()=>reject(new Error('Не удалось прочитать изображение. Проверьте формат файла.'));img.src=url;});}finally{URL.revokeObjectURL(url);}
}
export function canvas(w:number,h:number){w=safeDimension(w);h=safeDimension(h);checkPixels(w,h);const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');if(!ctx)throw new Error('Браузер не поддерживает Canvas.');return {c,ctx};}
export async function canvasResult(c:HTMLCanvasElement,name:string,format='png',quality=85):Promise<ResultFile>{
 const mime=`image/${format}`;
 const blob=await new Promise<Blob>((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('Не удалось сохранить изображение.')),mime,quality/100));
 const actual=blob.type.split('/')[1];return {name:name.replace(/\.[^.]+$/,`.${actual==='jpeg'?'jpg':actual}`),type:blob.type,data:new Uint8Array(await blob.arrayBuffer())};
}
export async function runImage({tool,files,options:o}:Job,progress:Progress,signal?:AbortSignal):Promise<ResultFile[]>{
 const out:ResultFile[]=[];
 if(tool==='gif'||tool==='contact-sheet'){
  if(!files.length)throw new Error('Выберите изображения.');
  const images:HTMLImageElement[]=[];for(const f of files){checkAbort(signal);images.push(await loadImage(f));}
  if(tool==='gif'){
   const {GIFEncoder,quantize,applyPalette}=await import('gifenc'),gif=GIFEncoder();
   const w=Number(o.width??600),h=Math.round(w*images[0].height/images[0].width),{c,ctx}=canvas(w,h);
   for(let i=0;i<images.length;i++){checkAbort(signal);ctx.fillStyle='#ffffff';ctx.fillRect(0,0,w,h);const [iw,ih]=fitSize(images[i].width,images[i].height,w,h);ctx.drawImage(images[i],(w-iw)/2,(h-ih)/2,iw,ih);const data=ctx.getImageData(0,0,w,h).data;const palette=quantize(data,256),index=applyPalette(data,palette);gif.writeFrame(index,w,h,{palette,delay:Number(o.delay??500),repeat:0});progress((i+1)/images.length*100,`Кадр ${i+1} из ${images.length}`);await tick();}
   gif.finish();return [{name:'filekit-animation.gif',type:'image/gif',data:gif.bytes()}];
  }
  const cols=Number(o.columns??3),cell=Number(o.cell??400),rowH=cell+42,{c,ctx}=canvas(cols*cell,Math.ceil(images.length/cols)*rowH);ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);
  images.forEach((im,i)=>{const x=(i%cols)*cell,y=Math.floor(i/cols)*rowH;const [w,h]=fitSize(im.width,im.height,cell-24,cell-24);ctx.drawImage(im,x+(cell-w)/2,y+(cell-h)/2,w,h);ctx.fillStyle='#333';ctx.font='16px sans-serif';ctx.textAlign='center';ctx.fillText(files[i].name,x+cell/2,y+cell+20,cell-20);});
  return [await canvasResult(c,'filekit-contact-sheet.png')];
 }
 for(let i=0;i<files.length;i++){
  checkAbort(signal);const file=files[i],im=await loadImage(file),iw=im.naturalWidth,ih=im.naturalHeight;
  let w=iw,h=ih,sx=0,sy=0,sw=iw,sh=ih;
  if(tool==='resize'){[w,h]=o.mode==='Проценты'?[Math.round(iw*Number(o.percent??50)/100),Math.round(ih*Number(o.percent??50)/100)]:fitSize(iw,ih,Number(o.width??1920),Number(o.height??1080));}
  if(tool==='crop-image'){
   const ratio=String(o.ratio??'1:1');
   if(ratio==='Свободно'){sx=Number(o.x??0);sy=Number(o.y??0);sw=Number(o.width??500);sh=Number(o.height??500);if(sx<0||sy<0||sx+sw>iw||sy+sh>ih)throw new Error(`${file.name}: область обрезки выходит за границы ${iw} × ${ih}.`);}
   else {const [a,b]=ratio.split(':').map(Number),r=a/b;if(iw/ih>r){sw=ih*r;sx=(iw-sw)/2;}else{sh=iw/r;sy=(ih-sh)/2;}}
   w=Math.round(sw);h=Math.round(sh);
  }
  const angle=Number(o.angle??90);if(tool==='rotate-image'&&angle%180!==0){w=ih;h=iw;}
  const border=tool==='border'?Number(o.border??32):0;if(border){w+=border*2;h+=border*2;}
  const {c,ctx}=canvas(w,h),format=String(o.format??'png');
  if(format==='jpeg'||border){ctx.fillStyle=border?String(o.color??'#4158ed'):'#ffffff';ctx.fillRect(0,0,w,h);}
  if(tool==='editor')ctx.filter=`brightness(${o.brightness??100}%) contrast(${o.contrast??100}%) saturate(${o.saturation??100}%) grayscale(${o.grayscale?100:0}%)`;
  if(tool==='rotate-image'){ctx.translate(w/2,h/2);ctx.rotate(angle*Math.PI/180);ctx.drawImage(im,-iw/2,-ih/2);ctx.setTransform(1,0,0,1,0,0);}
  else if(tool==='flip'){ctx.translate(o.direction==='Вертикально'?0:w,o.direction==='Вертикально'?h:0);ctx.scale(o.direction==='Вертикально'?1:-1,o.direction==='Вертикально'?-1:1);ctx.drawImage(im,0,0);ctx.setTransform(1,0,0,1,0,0);}
  else ctx.drawImage(im,sx,sy,sw,sh,border,border,w-border*2,h-border*2);
  ctx.filter='none';
  if(tool==='watermark-image'){const label=String(o.text??'');if(!label.trim())throw new Error('Введите текст водяного знака.');const size=Number(o.size??40);ctx.font=`600 ${size}px sans-serif`;ctx.fillStyle=String(o.color??'#4158ed');ctx.globalAlpha=Number(o.opacity??65)/100;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,w/2,o.position==='Сверху'?size+20:o.position==='По центру'?h/2:h-size-20,w-30);}
  if(tool==='meme'){
   if(!String(o.top??'').trim()&&!String(o.bottom??'').trim())throw new Error('Введите хотя бы одну подпись.');
   const size=Number(o.size??48);ctx.font=`900 ${size}px Impact, sans-serif`;ctx.textAlign='center';ctx.lineJoin='round';ctx.lineWidth=Math.max(2,size/12);ctx.strokeStyle='#000';ctx.fillStyle='#fff';ctx.textBaseline='top';const top=String(o.top??'').toUpperCase(),bottom=String(o.bottom??'').toUpperCase();ctx.strokeText(top,w/2,20,w-30);ctx.fillText(top,w/2,20,w-30);ctx.textBaseline='bottom';ctx.strokeText(bottom,w/2,h-20,w-30);ctx.fillText(bottom,w/2,h-20,w-30);
  }
  if(tool==='blur'){
   const x=Number(o.x??0),y=Number(o.y??0),bw=Number(o.width??200),bh=Number(o.height??200),r=Number(o.radius??20);
   if(x<0||y<0||x+bw>w||y+bh>h)throw new Error('Область размытия выходит за границы изображения.');
   ctx.save();ctx.beginPath();ctx.rect(x,y,bw,bh);ctx.clip();ctx.filter=`blur(${r}px)`;ctx.drawImage(im,0,0);ctx.restore();
  }
  out.push(await canvasResult(c,outputName(file.name,tool,format),format,Number(o.quality??85)));c.width=1;c.height=1;
  checkAbort(signal);progress((i+1)/files.length*100,`Обработано ${i+1} из ${files.length}`);await tick();
 }
 return out;
}
