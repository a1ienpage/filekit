import {runPDF} from './pdf';
import type {Job} from '../types';
self.onmessage=async(e:MessageEvent<Job>)=>{try{const files=await runPDF(e.data,(value,message)=>self.postMessage({progress:value,message}));self.postMessage({files});}catch(error){self.postMessage({error:error instanceof Error?error.message:String(error)});}};
