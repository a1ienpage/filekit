export function parsePages(value:string,count:number):number[] {
 if(!value.trim())return Array.from({length:count},(_,i)=>i);
 const out:number[]=[];
 for(const part of value.split(',')){
  const m=part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
  if(!m)throw new Error('Неверный диапазон страниц. Пример: 1, 3-5.');
  const a=Number(m[1]),b=Number(m[2]??a);
  if(a<1||b<1||a>count||b>count)throw new Error(`В документе ${count} стр. Проверьте номера.`);
  const step=a<=b?1:-1;for(let p=a;;p+=step){out.push(p-1);if(p===b)break;}
  if(out.length>10000)throw new Error('Слишком много страниц в результате.');
 }
 return out;
}
export function outputName(name:string,suffix:string,ext:string){return `${name.replace(/\.[^.]+$/,'')}-${suffix}.${ext}`;}
export function fitSize(w:number,h:number,mw:number,mh:number):[number,number]{const ratio=Math.min(mw/w,mh/h);return [Math.max(1,Math.round(w*ratio)),Math.max(1,Math.round(h*ratio))];}
export const bytes=(value:string)=>new TextEncoder().encode(value);
export function sizeLabel(n:number){return n<1024?`${n} Б`:n<1048576?`${(n/1024).toFixed(1)} КБ`:`${(n/1048576).toFixed(1)} МБ`;}
export function checkAbort(signal?:AbortSignal){if(signal?.aborted)throw new DOMException('Обработка отменена','AbortError');}
export const tick=()=>new Promise<void>(r=>setTimeout(r,0));
export function safeDimension(v:number){if(!Number.isFinite(v)||v<1||v>16000)throw new Error('Размер должен быть от 1 до 16000 px.');return Math.round(v);}
export function checkPixels(w:number,h:number){if(w*h>40_000_000)throw new Error('Изображение слишком большое (максимум 40 мегапикселей). Уменьшите размеры.');}
