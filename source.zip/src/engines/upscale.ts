import * as tf from '@tensorflow/tfjs';
import {canvas} from './image';
import {checkAbort} from './utils';
import type {Progress} from '../types';
export async function upscaleImage(image:HTMLImageElement,progress:Progress,signal?:AbortSignal){
 try{await tf.setBackend('webgl');}catch{await tf.setBackend('cpu');}await tf.ready();
 const model=await tf.loadLayersModel(new URL(`${import.meta.env.BASE_URL}models/upscale/model.json`,document.baseURI).href);
 const source=tf.browser.fromPixels(image).toFloat(),{c,ctx}=canvas(image.width*2,image.height*2),tile=64,padding=6;
 let completed=0;const total=Math.ceil(image.width/tile)*Math.ceil(image.height/tile);
 try{
  for(let y=0;y<image.height;y+=tile)for(let x=0;x<image.width;x+=tile){
   checkAbort(signal);const x0=Math.max(0,x-padding),y0=Math.max(0,y-padding),x1=Math.min(image.width,x+tile+padding),y1=Math.min(image.height,y+tile+padding),w=Math.min(tile,image.width-x),h=Math.min(tile,image.height-y);
   const output=tf.tidy(()=>{
    const input=source.slice([y0,x0,0],[y1-y0,x1-x0,3]).expandDims(0);
    const prediction=model.predict(input) as tf.Tensor4D;
    return prediction.squeeze([0]).slice([(y-y0)*2,(x-x0)*2,0],[h*2,w*2,3]).div(255).clipByValue(0,1) as tf.Tensor3D;
   });
   try{const pixels=await tf.browser.toPixels(output);ctx.putImageData(new ImageData(new Uint8ClampedArray(pixels),w*2,h*2),x*2,y*2);}finally{output.dispose();}
   progress(++completed/total*95,'Увеличиваем изображение…');await tf.nextFrame();
  }
  return c;
 }finally{source.dispose();model.dispose();}
}
