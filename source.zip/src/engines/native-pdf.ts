import mupdf from 'mupdf';
import type {Job,Progress,ResultFile} from '../types';
import {bytes,outputName,parsePages,checkPixels} from './utils';
import {PDFDocument} from 'pdf-lib';
const encode=(name:string,type:string,data:Uint8Array):ResultFile=>({name,type,data:new Uint8Array(data)});
function open(data:ArrayBuffer,password=''){
 const doc=new mupdf.PDFDocument(data);
 if(doc.needsPassword()&&!doc.authenticatePassword(password)){doc.destroy();throw new Error('Документ защищён паролем. Используйте «Снять пароль» с действующим паролем.');}
 if(doc.countPages()>1000){doc.destroy();throw new Error('Максимум 1000 страниц за одну операцию.');}return doc;
}
function save(doc:InstanceType<typeof mupdf.PDFDocument>,options:string|Record<string,string|number>='garbage=4,compress=yes'){
 const buffer=doc.saveToBuffer(options);try{return new Uint8Array(buffer.asUint8Array());}finally{buffer.destroy();}
}
function render(doc:InstanceType<typeof mupdf.PDFDocument>,index:number,scale:number,format='png',quality=85){
 const page=doc.loadPage(index);try{
  const b=page.getBounds();checkPixels(Math.ceil((b[2]-b[0])*scale),Math.ceil((b[3]-b[1])*scale));
  const pix=page.toPixmap(mupdf.Matrix.scale(scale,scale),mupdf.ColorSpace.DeviceRGB,false,true);
  try{return {data:new Uint8Array(format==='jpeg'?pix.asJPEG(quality):pix.asPNG()),width:b[2]-b[0],height:b[3]-b[1]};}finally{pix.destroy();}
 }finally{page.destroy();}
}
function texts(doc:InstanceType<typeof mupdf.PDFDocument>){
 const out:string[]=[];
 for(let i=0;i<doc.countPages();i++){const p=doc.loadPage(i);try{const t=p.toStructuredText('preserve-whitespace');try{out.push(t.asText());}finally{t.destroy();}}finally{p.destroy();}}
 return out;
}
export async function runNative({tool,files,options:o}:Job,progress:Progress):Promise<ResultFile[]>{
 const out:ResultFile[]=[];
 if(tool==='compare'){
  if(files.length!==2)throw new Error('Выберите ровно два PDF.');
  const a=open(files[0].data),b=open(files[1].data);
  try{const x=texts(a),y=texts(b);let report=`Сравнение текста: ${files[0].name} / ${files[1].name}\n\n`;
   for(let i=0;i<Math.max(x.length,y.length);i++)report+=`Страница ${i+1}: ${x[i]===y[i]?'одинаковый текст':'РАЗЛИЧАЕТСЯ'}\n${x[i]===y[i]?'':`--- Документ 1 ---\n${x[i]??'[нет страницы]'}\n--- Документ 2 ---\n${y[i]??'[нет страницы]'}\n`}\n`;
   return [encode('filekit-comparison.txt','text/plain',bytes(report))];
  }finally{a.destroy();b.destroy();}
 }
 for(let f=0;f<files.length;f++){
  const file=files[f],doc=open(file.data,String(o.password??''));
  try{
   const indices=parsePages(String(o.pages??''),doc.countPages());
   if(tool==='preview'){
    const index=Math.min(Math.max(0,Number(o.page??0)),doc.countPages()-1),r=render(doc,index,0.7);
    out.push(encode('preview.png','image/png',r.data),encode('info.json','application/json',bytes(JSON.stringify({pages:doc.countPages(),width:r.width,height:r.height}))));
   }else if(tool==='extract-images'){
    for(let n=1;n<doc.countObjects();n++){const obj=doc.newIndirect(n);let im:ReturnType<typeof doc.loadImage>|null=null;try{if(obj.get('Subtype').asName()!=='Image')continue;im=doc.loadImage(obj);const pix=im.toPixmap();try{out.push(encode(outputName(file.name,`image-${n}`,'png'),'image/png',pix.asPNG()));}finally{pix.destroy();}}finally{im?.destroy();obj.destroy();}}
    if(!out.length)throw new Error('Встроенные растровые изображения не найдены.');
   }else if(tool==='protect'){
    const password=String(o.password??'');if(password.includes(','))throw new Error('Пароль не должен содержать запятую.');if(!password.trim())throw new Error('Введите непустой пароль.');if(new TextEncoder().encode(password).length>127)throw new Error('Пароль слишком длинный (максимум 127 байт).');
    out.push(encode(outputName(file.name,'protected','pdf'),'application/pdf',save(doc,{'garbage':4,'compress':'yes','encrypt':'aes-256','user-password':password,'owner-password':password})));
   }else if(tool==='unlock'){out.push(encode(outputName(file.name,'unlocked','pdf'),'application/pdf',save(doc,'garbage=4,compress=yes,encrypt=none')));}
   else if(tool==='repair'||(tool==='compress'&&o.mode!=='Скан: компактный PDF')){out.push(encode(outputName(file.name,tool,'pdf'),'application/pdf',save(doc)));}
   else if(tool==='redact'){
    const x=Number(o.x??40),y=Number(o.y??40),w=Number(o.width??200),h=Number(o.height??60);
    for(const i of indices){const p=doc.loadPage(i);try{const b=p.getBounds();if(x<0||y<0||w<=0||h<=0||x+w>b[2]-b[0]||y+h>b[3]-b[1])throw new Error('Область удаления выходит за границы страницы.');const a=p.createAnnotation('Redact');a.setRect([b[0]+x,b[1]+y,b[0]+x+w,b[1]+y+h]);a.update();a.destroy();p.applyRedactions(true,2,2,0);}finally{p.destroy();}}
    out.push(encode(outputName(file.name,'redacted','pdf'),'application/pdf',save(doc,'garbage=4,compress=yes,clean=yes')));
   }else if(tool==='pdf-images'||tool==='compress'){
    const raster=tool==='compress'?await PDFDocument.create():null;
    for(let j=0;j<indices.length;j++){
     const format=tool==='compress'?'jpeg':String(o.format??'png'),r=render(doc,indices[j],Number(o.scale??1.5),format,Number(o.quality??85));
     if(raster){const im=await raster.embedJpg(r.data);raster.addPage([r.width,r.height]).drawImage(im,{x:0,y:0,width:r.width,height:r.height});}
     else out.push(encode(outputName(file.name,`page-${indices[j]+1}`,format==='jpeg'?'jpg':'png'),`image/${format}`,r.data));
     progress((f+(j+1)/indices.length)/files.length*100,`Страница ${j+1} из ${indices.length}`);
    }
    if(raster)out.push(encode(outputName(file.name,'compact-scan','pdf'),'application/pdf',await raster.save()));
   }else if(tool==='pdf-pptx'){
    const {default:PptxGenJS}=await import('pptxgenjs');const pres=new PptxGenJS();pres.author='';pres.subject='PDF pages';
    const p=doc.loadPage(0),bounds=p.getBounds();p.destroy();const w=(bounds[2]-bounds[0])/72,h=(bounds[3]-bounds[1])/72;
    pres.defineLayout({name:'PDF',width:w,height:h});pres.layout='PDF';
    for(let i=0;i<doc.countPages();i++){const r=render(doc,i,Number(o.scale??1.5));let bin='';for(const byte of r.data)bin+=String.fromCharCode(byte);const slide=pres.addSlide();const ratio=Math.min(w/r.width,h/r.height);slide.addImage({data:`image/png;base64,${btoa(bin)}`,x:(w-r.width*ratio)/2,y:(h-r.height*ratio)/2,w:r.width*ratio,h:r.height*ratio});progress((i+1)/doc.countPages()*95,`Слайд ${i+1}`);}
    const data=await pres.write({outputType:'arraybuffer'}) as ArrayBuffer;out.push(encode(outputName(file.name,'slides','pptx'),'application/vnd.openxmlformats-officedocument.presentationml.presentation',new Uint8Array(data)));
   }else{
    const content=texts(doc);if(!content.some(s=>s.trim()))throw new Error('В PDF нет текста. Сначала используйте распознавание OCR.');
    if(tool==='pdf-text'){const md=o.format==='md';out.push(encode(outputName(file.name,'text',md?'md':'txt'),'text/plain',bytes(content.map((s,i)=>md?`## Страница ${i+1}\n\n${s}`:s).join('\n\n'))));}
    else if(tool==='pdf-word'){
     const {Document,Paragraph,TextRun,Packer}=await import('docx');const d=new Document({sections:content.map(s=>({children:s.split('\n').map(line=>new Paragraph({children:[new TextRun(line)]}))}))});
     out.push(encode(outputName(file.name,'text','docx'),'application/vnd.openxmlformats-officedocument.wordprocessingml.document',new Uint8Array(await (await Packer.toBlob(d)).arrayBuffer())));
    }else if(tool==='pdf-excel'){
     const {default:ExcelJS}=await import('exceljs');const wb=new ExcelJS.Workbook();const ws=wb.addWorksheet('Text');ws.addRow(['Page','Line','Text','X','Y']);
     for(let i=0;i<doc.countPages();i++){const p=doc.loadPage(i),t=p.toStructuredText('');try{const json=JSON.parse(t.asJSON());let line=0;for(const block of json.blocks??[])for(const l of block.lines??[]){ws.addRow([i+1,++line,l.text??'',l.bbox?.x??'',l.bbox?.y??'']);}}finally{t.destroy();p.destroy();}}
     ws.getColumn(3).width=90;out.push(encode(outputName(file.name,'text','xlsx'),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',new Uint8Array(await wb.xlsx.writeBuffer())));
    }else throw new Error('Неизвестная операция PDF.');
   }
  }finally{doc.destroy();}
  progress((f+1)/files.length*100,`Обработано ${f+1} из ${files.length}`);
 }
 return out;
}
