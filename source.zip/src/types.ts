export type Group = 'pdf' | 'image';
export type Values = Record<string, string | number | boolean>;
export type Field = { key:string; label:string; type:'text'|'number'|'range'|'select'|'color'|'checkbox'|'textarea'|'password'; value:string|number|boolean; min?:number; max?:number; step?:number; choices?:{value:string;label:string}[]; hint?:string };
export type Tool = {id:string; name:string; desc:string; group:Group; icon:string; accept:string; fields:Field[]; multiple?:boolean; minFiles?:number; note?:string; badge?:string};
export type InputFile = {name:string;type:string;data:ArrayBuffer};
export type ResultFile = {name:string;type:string;data:Uint8Array};
export type Progress = (value:number, message:string)=>void;
export type Job = {tool:string;files:InputFile[];options:Values};
