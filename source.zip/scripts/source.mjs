import fs from 'node:fs/promises';
import path from 'node:path';
import JSZip from 'jszip';
const root=process.cwd(),zip=new JSZip();
const skip=new Set(['node_modules','dist','.git','.DS_Store','source.zip','third-party-licenses.zip','.vite']);
async function walk(dir,prefix=''){for(const e of await fs.readdir(dir,{withFileTypes:true})){if(skip.has(e.name)||e.name.endsWith('.tsbuildinfo')||e.name.endsWith('.zip'))continue;const name=path.posix.join(prefix,e.name),file=path.join(dir,e.name);if(e.isDirectory())await walk(file,name);else zip.file(name,await fs.readFile(file),{unixPermissions:e.name.endsWith('.command')?0o100755:0o100644});}}
await walk(root);await fs.writeFile('public/source.zip',await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',platform:'UNIX'}));
const notices=new JSZip();
async function licenses(dir,prefix=''){for(const e of await fs.readdir(dir,{withFileTypes:true})){if(e.name.startsWith('.'))continue;const file=path.join(dir,e.name),name=path.posix.join(prefix,e.name);if(e.isDirectory()){if(prefix.split('/').length<4)await licenses(file,name);}else if(/^(license|licence|copying|notice|copyright)(\.|$)/i.test(e.name)||e.name==='ThirdPartyLicenses.json')notices.file(name,await fs.readFile(file));}}
await licenses('node_modules');await fs.writeFile('public/third-party-licenses.zip',await notices.generateAsync({type:'nodebuffer',compression:'DEFLATE',platform:'UNIX'}));
