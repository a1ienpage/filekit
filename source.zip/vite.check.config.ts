import {defineConfig} from 'vite';
export default defineConfig({base:'./',worker:{format:'es'},build:{outDir:'/private/tmp/filekit-browser-check',emptyOutDir:true,rolldownOptions:{input:'browser-check.html'}}});
