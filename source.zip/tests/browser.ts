import {runImage,loadImage,canvas,canvasResult} from '../src/engines/image';
import {runAdvanced} from '../src/engines/advanced';
import {pdfJob} from '../src/engines/client';
import {sanitizeDocument} from '../src/engines/office';
import {PDFDocument} from 'pdf-lib';
import type {InputFile,ResultFile} from '../src/types';
import '../src/styles.css';
const status=document.querySelector('#status')!,list=document.querySelector('#results')!;
const assert=(condition:unknown,message:string)=>{if(!condition)throw new Error(message);};
const noop=()=>{};
const asInput=(f:ResultFile):InputFile=>({name:f.name,type:f.type,data:new Uint8Array(f.data).buffer});
const input=async(url:URL,name:string):Promise<InputFile>=>({name,type:'',data:await fetch(url).then(r=>r.arrayBuffer())});
const dims=async(r:ResultFile)=>{const im=await loadImage(new Blob([new Uint8Array(r.data)],{type:r.type}));return [im.width,im.height];};
async function run(){
 const records:{name:string;pass:boolean;detail?:string}[]=[];
 async function test(name:string,fn:()=>Promise<void>){status.textContent=name;const li=document.createElement('li');list.append(li);try{await fn();records.push({name,pass:true});li.textContent=`PASS — ${name}`;li.style.color='#397e52';}catch(e){const message=e instanceof Error?e.message:String(e);records.push({name,pass:false,detail:message});li.textContent=`FAIL — ${name}: ${message}`;li.style.color='#b94a48';}}
 const {c,ctx}=canvas(600,200);ctx.fillStyle='#fff';ctx.fillRect(0,0,600,200);ctx.fillStyle='#151515';ctx.font='50px sans-serif';ctx.fillText('HELLO FILEKIT 2026',30,110);const photo=asInput(await canvasResult(c,'fixture.png'));
 for(const [tool,options,w,h] of [
 ['resize',{width:300,height:300},300,100],['crop-image',{ratio:'1:1'},200,200],['crop-image',{ratio:'Свободно',x:10,y:10,width:50,height:60},50,60],['rotate-image',{angle:90},200,600],['flip',{direction:'Вертикально'},600,200],['watermark-image',{text:'TEST',size:40,position:'По центру'},600,200],['editor',{brightness:120,contrast:90,saturation:50},600,200],['meme',{top:'HELLO',bottom:'TEST',size:30},600,200],['blur',{x:20,y:40,width:200,height:80,radius:20},600,200],['border',{border:20},640,240],['clean-image',{format:'jpeg'},600,200],['compress-image',{format:'webp',quality:50},600,200],['convert-image',{format:'png'},600,200],['contact-sheet',{columns:2,cell:200},400,242]
 ] as const){await test(`${tool} produces ${w} × ${h}`,async()=>{const [r]=await runImage({tool,files:[photo],options},noop);assert(JSON.stringify(await dims(r))===JSON.stringify([w,h]),'incorrect output dimensions');});}
 await test('GIF exports a valid animation',async()=>{const [r]=await runImage({tool:'gif',files:[photo,photo],options:{width:300,delay:200}},noop);assert(new TextDecoder().decode(r.data.slice(0,3))==='GIF','missing GIF header');assert((await dims(r))[0]===300,'invalid GIF dimensions');});
 await test('invalid crop is rejected',async()=>{let failed=false;try{await runImage({tool:'crop-image',files:[photo],options:{ratio:'Свободно',x:99999,y:0,width:10,height:10}},noop);}catch{failed=true;}assert(failed,'out of bounds crop accepted');});
 await test('HTML sanitizer strips active and remote content',async()=>{const html=sanitizeDocument('<script>alert(1)</script><img src="https://example.com/private"><p style="background:url(https://example.com)">OK</p>');assert(!html.includes('example.com')&&!html.includes('<script')&&html.includes('OK'),'unsafe HTML retained');});
 for(const [tool,url,name] of [['docx-pdf',new URL('./fixtures/sample.docx',import.meta.url),'sample.docx'],['xlsx-pdf',new URL('./fixtures/sample.xlsx',import.meta.url),'sample.xlsx'],['html-pdf',new URL('./fixtures/sample.html',import.meta.url),'sample.html']] as const){await test(`${tool} creates a readable PDF`,async()=>{const [r]=await runAdvanced({tool,files:[await input(url,name)],options:{}},noop);const d=await PDFDocument.load(r.data);assert(d.getPageCount()>=1,'no pages');const preview=await pdfJob({tool:'preview',files:[asInput(r)],options:{}},noop);assert(preview[0].data.length>1500,'blank rendered page');});}
 let imagePDF:ResultFile;
 await test('images to PDF preserves page count',async()=>{[imagePDF]=await runAdvanced({tool:'images-pdf',files:[photo,photo],options:{paper:'A4',margin:24}},noop);assert((await PDFDocument.load(imagePDF.data)).getPageCount()===2,'wrong page count');});
 await test('extract embedded images from PDF',async()=>{const r=await pdfJob({tool:'extract-images',files:[asInput(imagePDF)],options:{}},noop);assert(r.length>=1,'no extracted images');assert((await dims(r[0]))[0]===600,'incorrect image');});
 await test('OCR image reads HELLO FILEKIT 2026',async()=>{const [r]=await runAdvanced({tool:'ocr-image',files:[photo],options:{language:'eng'}},noop);const text=new TextDecoder().decode(r.data);assert(text.includes('HELLO')&&text.includes('2026'),text);});
 await test('OCR PDF produces an actual searchable text layer',async()=>{const [r]=await runAdvanced({tool:'ocr-pdf',files:[asInput(imagePDF)],options:{language:'eng',format:'PDF с поиском',scale:1}},noop);const [text]=await pdfJob({tool:'pdf-text',files:[asInput(r)],options:{}},noop);assert(new TextDecoder().decode(text.data).includes('HELLO'),'missing recognized PDF text');});
 await test('Russian OCR recognizes Cyrillic',async()=>{const {c,ctx}=canvas(700,200);ctx.fillStyle='#fff';ctx.fillRect(0,0,700,200);ctx.fillStyle='#111';ctx.font='55px sans-serif';ctx.fillText('ПРИВЕТ АЛИАСКАР',25,115);const f=asInput(await canvasResult(c,'russian.png'));const [r]=await runAdvanced({tool:'ocr-image',files:[f],options:{language:'rus+eng'}},noop);assert(new TextDecoder().decode(r.data).includes('ПРИВЕТ'),'Russian language recognition failed');});
 status.textContent=`${records.filter(r=>r.pass).length}/${records.length} passed`;
 const report=document.createElement('pre');report.id='report';report.textContent=JSON.stringify(records,null,2);document.body.append(report);
}
document.querySelector('#run')!.addEventListener('click',()=>{(document.querySelector('#run') as HTMLButtonElement).disabled=true;void run().catch(e=>{status.textContent=`HARNESS ERROR: ${String(e)}`;});});
