import {describe,it,expect} from 'vitest';
import {parsePages, outputName, fitSize} from '../src/engines/utils';
describe('page selection',()=>{
 it('preserves reverse ranges and explicit ordering',()=>expect(parsePages('3, 5-4, 1',5)).toEqual([2,4,3,0]));
 it('defaults to all pages',()=>expect(parsePages('',3)).toEqual([0,1,2]));
 it.each(['0','7','2-a','1,,2','1.5','-1'])('rejects invalid selection %s',value=>expect(()=>parsePages(value,5)).toThrow());
});
it('names never overwrite extensions incorrectly',()=>expect(outputName('my.file.pdf','rotated','pdf')).toBe('my.file-rotated.pdf'));
it('keeps image aspect ratio inside bounds',()=>expect(fitSize(2000,1000,500,500)).toEqual([500,250]));
