# FileKit

Goal: a free public GitHub Pages app combining working PDF and image tools. Files are processed locally. Model downloads are explicit. No accounts, backend, API keys or upload service.

Design: warm white canvas, cobalt accents, serif editorial hero, compact tool cards, searchable catalog, PDF/Image filters. Shared workspace: file list, preview, settings, progress, downloadable results. Russian UI. Responsive and keyboard accessible. All available cards execute real operations. Advanced conversion limitations are visible before running.

Implementation:
1. Typed tool catalog and option schemas. File/result contract shared by engines and UI.
2. PDF engine: page operations, overlays, image export, text/Office export, OCR, password/repair/optimization using local libraries. Tests verify page order, preservation, passwords and range validation.
3. Image engine: canvas batch transforms, compression, formats, contact sheets, GIF, metadata stripping and OCR; optional local background removal/upscaling. Guard memory, animation limitations, malformed inputs and cancellation.
4. React workspace: file management, previews, options, reorder, progress/cancel and result reuse. Lazy processing modules. Screenshot checks desktop/mobile and representative real file flows.
5. GitHub Pages workflow, licenses, concise setup guide, portable publication archive. Build, integration tests and a final source review.

Files: src/catalog.ts, src/types.ts; src/engines/pdf.ts, image.ts, advanced.ts, worker.ts, client.ts, utils.ts; src/components/Workspace.tsx, Options.tsx; src/App.tsx, styles.css. Tests cover exported engine behavior with real PDF fixtures and corrupt input. Browser verification covers canvas output and downloads.

Constraints: no misleading perfect compression/conversion claims; no fake buttons; preserve original files; no source-file content sent to services. PDF redaction must remove actual content or be omitted. Commercial SaaS and invitation signing are outside static hosting. Office conversion is explicitly basic. No publishing without user request.
